'''
Adaptive Multistrategy Particle Swarm Optimization
for Hyperspectral Remote Sensing
Image Band Selection
'''

import numpy as np
import scipy.stats as stats
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


class AMSPSO_BS:
    def __init__(self, num_bands, pop_size=50, max_iter=100, n_selected=10, ta=20, wmax=0.9, wmin=0.4):
        self.num_bands = num_bands  # 总波段数（21）
        self.pop_size = pop_size  # 种群规模
        self.max_iter = max_iter  # 最大迭代次数
        self.n_selected = n_selected  # 选中波段数
        self.ta = ta  # 策略概率调整间隔
        self.wmax = wmax  # 最大惯性权重
        self.wmin = wmin  # 最小惯性权重
        self.pop = self._initialize_population()  # 初始化种群
        self.pbest = self.pop.copy()  # 个体最优
        self.pbest_fitness = np.zeros(pop_size)
        self.gbest = None  # 全局最优
        self.gbest_fitness = -np.inf
        self.pus_prob = np.ones(5) / 5  # 5种策略的初始概率
        self.ns_flag = np.zeros((pop_size, 5))  # 策略成功记录
        self.nf_flag = np.zeros((pop_size, 5))  # 策略失败记录

    def _initialize_population(self):
        """二进制编码初始化种群，确保每个个体恰好选中n_selected个波段"""
        pop = np.zeros((self.pop_size, self.num_bands), dtype=int)
        for i in range(self.pop_size):
            indices = np.random.choice(self.num_bands, self.n_selected, replace=False)
            pop[i, indices] = 1
        return pop

    def _calc_ld(self, X, y):
        """计算线性判别值LD = tr(Sb * Sw^-1)"""
        classes = np.unique(y)
        K = len(classes)
        mu0 = np.mean(X, axis=0)  # 总体均值
        Sb = np.zeros((X.shape[1], X.shape[1]))
        Sw = np.zeros_like(Sb)

        for c in classes:
            Xc = X[y == c]
            muc = np.mean(Xc, axis=0)
            P = len(Xc) / len(X)  # 先验概率
            Sb += P * np.outer(muc - mu0, muc - mu0)
            Sw += P * np.cov(Xc.T)

        # 处理奇异矩阵（添加微小扰动）
        Sw += np.eye(Sw.shape[0]) * 1e-6
        return np.trace(np.dot(np.linalg.inv(Sw), Sb))

    def _calc_mmi(self, X):
        """计算平均互信息MMI"""
        n_bands = X.shape[1]
        if n_bands < 2:
            return 1e-6  # 避免除零
        mi_sum = 0
        for i in range(n_bands):
            for j in range(i + 1, n_bands):
                # 计算两波段间的互信息
                hist, _, _ = np.histogram2d(X[:, i], X[:, j], bins=10)
                pxy = hist / np.sum(hist)
                px = np.sum(pxy, axis=1)
                py = np.sum(pxy, axis=0)
                px_py = np.outer(px, py)
                mask = pxy > 0
                mi_sum += np.sum(pxy[mask] * np.log(pxy[mask] / px_py[mask]))
        return mi_sum / (n_bands * (n_bands - 1) / 2)

    def _fitness(self, individual, X, y):
        """适应度函数：LD/MMI"""
        selected_bands = np.where(individual == 1)[0]
        if len(selected_bands) < 2:
            return -np.inf
        X_selected = X[:, selected_bands]
        ld = self._calc_ld(X_selected, y)
        mmi = self._calc_mmi(X_selected)
        return ld / mmi if mmi != 0 else -np.inf

    def _update_velocity_position(self, particle_idx, strategy_idx, w, c1, c2):
        """根据5种策略更新粒子速度和位置"""
        particle = self.pop[particle_idx]
        pbest = self.pbest[particle_idx]
        gbest = self.gbest
        r1, r2 = np.random.rand(), np.random.rand()

        if strategy_idx == 0:
            # 策略1：个体最优+全局最优
            vel = w * np.random.randn(self.num_bands) + c1 * r1 * (pbest - particle) + c2 * r2 * (gbest - particle)
        elif strategy_idx == 1:
            # 策略2：种群平均位置
            pop_mean = np.mean(self.pop, axis=0)
            vel = w * np.random.randn(self.num_bands) + c1 * r1 * (pop_mean - particle)
        elif strategy_idx == 2:
            # 策略3：平均最优位置
            pbest_mean = np.mean(self.pbest, axis=0)
            vel = w * np.random.randn(self.num_bands) + c1 * r1 * (pbest_mean - particle)
        elif strategy_idx == 3:
            # 策略4：全局最优+随机粒子差
            p1, p2 = np.random.choice(self.pop_size, 2, replace=False)
            vel = w * np.random.randn(self.num_bands) + c1 * r1 * (gbest - particle) + c2 * r2 * (
                        self.pop[p1] - self.pop[p2])
        else:
            # 策略5：随机粒子差
            p1, p2 = np.random.choice(self.pop_size, 2, replace=False)
            vel = w * np.random.randn(self.num_bands) + c1 * r1 * (self.pop[p1] - self.pop[p2]) + c2 * r2 * (
                        self.pop[p2] - self.pop[p1])

        # Sigmoid函数转换为概率，二进制化
        prob = 1 / (1 + np.exp(-vel))
        new_pos = np.where(prob > np.random.rand(self.num_bands), 1, 0)

        # 确保恰好选中n_selected个波段
        selected = np.where(new_pos == 1)[0]
        if len(selected) != self.n_selected:
            if len(selected) > self.n_selected:
                drop = np.random.choice(selected, len(selected) - self.n_selected, replace=False)
                new_pos[drop] = 0
            else:
                add = np.random.choice(np.where(new_pos == 0)[0], self.n_selected - len(selected), replace=False)
                new_pos[add] = 1
        return new_pos

    def fit(self, X, y):
        """训练模型：X为展平后的光谱数据(n_samples, num_bands)，y为标签"""
        # 初始化适应度
        for i in range(self.pop_size):
            self.pbest_fitness[i] = self._fitness(self.pop[i], X, y)
        self.gbest_idx = np.argmax(self.pbest_fitness)
        self.gbest = self.pbest[self.gbest_idx].copy()
        self.gbest_fitness = self.pbest_fitness[self.gbest_idx]

        for t in range(self.max_iter):
            # 动态调整惯性权重和加速因子
            w = self.wmax - (self.wmax - self.wmin) * t / self.max_iter
            c = (w + 1 + 2 * np.sqrt(w)) / 2
            c1 = c2 = c

            # 迭代更新粒子
            for i in range(self.pop_size):
                # 按概率选择策略
                strategy_idx = np.random.choice(5, p=self.pus_prob)
                new_pos = self._update_velocity_position(i, strategy_idx, w, c1, c2)

                # 计算新适应度
                new_fitness = self._fitness(new_pos, X, y)
                # 更新个体最优
                if new_fitness > self.pbest_fitness[i]:
                    self.pbest[i] = new_pos.copy()
                    self.pbest_fitness[i] = new_fitness
                    self.ns_flag[i, strategy_idx] += 1  # 策略成功
                else:
                    self.nf_flag[i, strategy_idx] += 1  # 策略失败

            # 更新全局最优
            current_best_idx = np.argmax(self.pbest_fitness)
            if self.pbest_fitness[current_best_idx] > self.gbest_fitness:
                self.gbest = self.pbest[current_best_idx].copy()
                self.gbest_fitness = self.pbest_fitness[current_best_idx]

            # 每ta次迭代调整策略概率
            if (t + 1) % self.ta == 0:
                s = np.sum(self.ns_flag, axis=0)
                f = np.sum(self.nf_flag, axis=0)
                s2 = np.where(s == 0, 1e-6, s)  # 避免除零
                s3 = s / (s2 + f)
                self.pus_prob = s3 / np.sum(s3)  # 归一化概率
                # 重置记录
                self.ns_flag = np.zeros_like(self.ns_flag)
                self.nf_flag = np.zeros_like(self.nf_flag)

            # if (t + 1) % 10 == 0:
            print(f"Iteration {t + 1}, Best Fitness: {self.gbest_fitness:.4f}")

        return np.where(self.gbest == 1)[0]

import time
# 使用示例
if __name__ == "__main__":
    # 模拟输入数据：512×640×21 -> 展平为(512*640, 21)
    start_time= time.time()
    rows, cols, bands = 512, 640, 21
    X = np.load(r'../Data_Mat/MSIdata.npy').reshape(-1, bands)
    y = np.load(r'../Data_Mat/MSImask2.npy').reshape(-1)

    # 数据预处理：归一化
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # 划分训练集（10%用于计算适应度）
    X_train, _, y_train, _ = train_test_split(X_scaled, y, test_size=0.9, random_state=42)

    # 初始化并运行算法
    amspso = AMSPSO_BS(num_bands=bands, n_selected=5)  # 选择10个波段
    selected_bands = amspso.fit(X_train, y_train)

    print(f"Selected bands: {sorted(selected_bands)}")
    print('time ',time.time()-start_time)

    #results = [5, 6, 7, 13, 14]