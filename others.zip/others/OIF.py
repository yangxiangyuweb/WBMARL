import numpy as np
from itertools import combinations
import os
import cv2

def read_hyper1(filepath):
    imglist=[]
    if filepath.find('sky')>=0:
        qianzhui='sky'
    if filepath.find('road')>=0:
        qianzhui='road'
    if filepath.find('forest')>=0:
        qianzhui='forest'
    if filepath.find('building')>=0:
        qianzhui='building'
    for i in range(len(os.listdir(filepath))):
        imgname=qianzhui+str(i)+'.tif'
        imgpath = os.path.join(filepath, imgname)
        print(imgpath)
        hyper = cv2.imread(imgpath, -1)
        imglist.append(hyper)
    imglist=np.array(imglist)
    return imglist

def read_pre_data(filepath):
    global band
    band=int(len(os.listdir(filepath)))
    hyper=np.zeros([256,320,band])
    i=0
    for imgname in os.listdir(filepath):
        imgpath = os.path.join(filepath, imgname)
        img = cv2.imread(imgpath, -1)
        hyper[:,:,i] = img
        i=i+1
    return hyper

def calculate_index(data, indices):
    # 根据波段组合计算指数值
    index_values = np.mean(data[:, indices], axis=1)
    return index_values

def oif_band_selection(data, num_selected_bands):
    num_bands = data.shape[1]  # 波段数量
    best_score = -np.inf
    best_indices = None

    # 遍历所有可能的波段组合
    for indices in combinations(range(num_bands), num_selected_bands):

        # 计算指数值
        index_values = calculate_index(data, indices)

        # 计算指数值的评估指标，这里使用平均值作为示例
        score = np.mean(index_values)
        print(indices, score)
        # 更新最佳指数值和波段组合
        if score > best_score:
            best_score = score
            best_indices = indices

    return best_indices
import time
strat_time= time.time()
filepath = r'I:\DATA\5.29aotf_data\trees\nan3_2ms_qingxi\3'
# spectrum_list=[]
filedir = r'D:\yangxiangyu\PythonWorks\maddpg_bandwidthSelect\MSI\\sky'
for name in os.listdir(filedir):
    filepath = os.path.join(filedir, name)
    Hyper = read_hyper1(filepath)
    Hyper = np.array(Hyper, np.uint8)
    data = Hyper
    num_selected_bands = 5

# 调用最佳指数法进行波段选择
    best_band_indices = oif_band_selection(data, num_selected_bands)
    print(time.time() - strat_time)
    print("最佳的波段组合: ", best_band_indices)