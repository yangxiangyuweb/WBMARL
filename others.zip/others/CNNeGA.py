'''
 Hyperspectral Image Band Selection Based on CNN
 Embedded GA (CNNeGA)
'''

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random

# --------------------------参数设置（参考论文）--------------------------
BAND_NUM = 21  # 输入波段数
SELECT_BANDS = 5  # 目标选择波段数
POPULATION_SIZE = 15  # 种群大小
MAX_GENERATIONS = 20  # 最大迭代代数
CROSSOVER_PROB = 0.9  # 交叉概率
MUTATION_PROB_INIT = 0.02  # 初始变异概率
MUTATION_PROB_FINAL = 0.1  # 最终变异概率
TRAIN_RATIO = 0.01  # 训练样本比例
INPUT_SHAPE = (11, 11, SELECT_BANDS)  # 3D-CNN输入块大小
DEVICE = torch.device("cuda:2" if torch.cuda.is_available() else "cpu")


# --------------------------3D-CNN模型（适应度函数）--------------------------
class CNN3D(nn.Module):
    def __init__(self, num_classes):
        super(CNN3D, self).__init__()
        # 3D卷积层（参考论文结构）
        self.conv1 = nn.Conv3d(1, 32, kernel_size=(3, 3, 3), padding=1)
        self.conv2 = nn.Conv3d(32, 64, kernel_size=(3, 3, 3), padding=1)
        self.conv3 = nn.Conv3d(64, 16, kernel_size=(3, 3, 3), padding=1)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.5)
        # 全连接层
        self.fc1 = nn.Linear(16 * 11 * 11 * SELECT_BANDS, 256)  # 适配输入块大小
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, num_classes)

    def forward(self, x):
        # x shape: (batch_size, 1, 11, 11, SELECT_BANDS)
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.relu(self.conv3(x))
        x = x.view(x.size(0), -1)  # 展平
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        return x


# --------------------------遗传算法核心模块--------------------------
def initialize_population(pop_size, band_num, select_num):
    """初始化种群：二进制向量表示选中波段"""
    population = []
    for _ in range(pop_size):
        individual = np.zeros(band_num, dtype=int)
        selected = np.random.choice(band_num, select_num, replace=False)
        individual[selected] = 1
        population.append(individual)
    return np.array(population)


def parent_check(parent1, parent2, select_num):
    """论文中的Parent Check Box：减少波段重复"""
    common = np.where(np.logical_and(parent1, parent2))[0]
    if len(common) > select_num // 2:
        retain_prob = len(common) / select_num
        if random.random() < retain_prob:
            new_p1 = np.zeros_like(parent1)
            new_p2 = np.zeros_like(parent2)
            new_p1[common] = 1
            new_p2[common] = 1
            # 补充剩余波段
            remaining1 = np.where(parent1 - new_p1)[0]
            remaining2 = np.where(parent2 - new_p2)[0]
            need = select_num - len(common)
            new_p1[np.random.choice(remaining1, need, replace=False)] = 1
            new_p2[np.random.choice(remaining2, need, replace=False)] = 1
            return new_p1, new_p2
    # 去除重复波段
    for p in [parent1, parent2]:
        duplicates = np.where(p)[0]
        if len(duplicates) > select_num:
            remove = np.random.choice(duplicates, len(duplicates)-select_num, replace=False)
            p[remove] = 0
    return parent1, parent2


def crossover(parent1, parent2):
    """两点交叉"""
    if random.random() < CROSSOVER_PROB:
        point1, point2 = sorted(random.sample(range(BAND_NUM), 2))
        child1 = np.concatenate([parent1[:point1], parent2[point1:point2], parent1[point2:]])
        child2 = np.concatenate([parent2[:point1], parent1[point1:point2], parent2[point2:]])
        return child1, child2
    return parent1.copy(), parent2.copy()


def mutate(individual, generation):
    """变异：随迭代增加概率"""
    mut_prob = MUTATION_PROB_INIT + (MUTATION_PROB_FINAL - MUTATION_PROB_INIT) * (generation / MAX_GENERATIONS)
    for i in range(BAND_NUM):
        if random.random() < mut_prob:
            individual[i] = 1 - individual[i]
    # 确保波段数量正确
    selected = np.sum(individual)
    if selected < SELECT_BANDS:
        individual[np.random.choice(np.where(individual == 0)[0], SELECT_BANDS - selected, replace=False)] = 1
    elif selected > SELECT_BANDS:
        individual[np.random.choice(np.where(individual == 1)[0], selected - SELECT_BANDS, replace=False)] = 0
    return individual


# --------------------------适应度计算--------------------------
class HSIDataset(Dataset):
    def __init__(self, hsi_data, labels, selected_bands, sample_indices):
        self.hsi_data = hsi_data
        self.rows, self.cols, _ = hsi_data.shape

        # 展平标签为1D数组（确保每个像素对应一个标签）
        self.labels = labels.flatten()  # 关键修正：强制展平为1D

        self.selected_bands = selected_bands
        self.sample_indices = sample_indices

        # 修正标签长度检查逻辑（用展平后的长度对比）
        # expected_size = self.rows * self.cols
        # if self.labels.shape[0] != expected_size:
        #     raise ValueError(
        #         f"Labels size {len(self.labels)} doesn't match HSI spatial dimensions {self.rows}x{self.cols} "
        #         f"(expected {expected_size})"
        #     )

    def __len__(self):
        return len(self.sample_indices)

    def __getitem__(self, idx):
        linear_idx = self.sample_indices[idx]
        r = linear_idx // self.cols
        c = linear_idx % self.cols

        # Boundary handling (same as before)
        pad = 5
        if r < pad or r >= self.rows - pad or c < pad or c >= self.cols - pad:
            block = np.zeros((11, 11, len(self.selected_bands)))
            r_start = max(0, r - pad)
            r_end = min(self.rows, r + pad + 1)
            c_start = max(0, c - pad)
            c_end = min(self.cols, c + pad + 1)
            block_start_r = pad - (r - r_start)
            block_start_c = pad - (c - c_start)
            block[block_start_r:block_start_r + (r_end - r_start),
            block_start_c:block_start_c + (c_end - c_start)] = \
                self.hsi_data[r_start:r_end, c_start:c_end, self.selected_bands]
        else:
            block = self.hsi_data[r - pad:r + pad + 1, c - pad:c + pad + 1, self.selected_bands]
        # print(self.labels.shape)
        label = self.labels[linear_idx]
        return torch.FloatTensor(block).unsqueeze(0), torch.LongTensor([label])

def calculate_fitness(population, hsi_data, labels, num_classes):
    """计算适应度：3D-CNN分类精度"""
    fitness = []
    rows, cols, _ = hsi_data.shape
    sample_indices = np.random.choice(rows * cols, int(rows * cols * TRAIN_RATIO), replace=False)
    model = CNN3D(num_classes).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    for individual in population:
        selected_bands = np.where(individual)[0]
        if len(selected_bands) != SELECT_BANDS:
            fitness.append(0.0)
            continue
        # 构建数据集
        dataset = HSIDataset(hsi_data, labels, selected_bands, sample_indices)
        if len(dataset) < 10:
            fitness.append(0.0)
            continue
        dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
        # 训练模型
        model.train()
        for epoch in range(5):
            total_loss = 0.0
            for inputs, y in dataloader:
                inputs, y = inputs.to(DEVICE), y.squeeze().to(DEVICE)
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, y)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
        # 评估精度
        print(individual,epoch,total_loss)
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for inputs, y in dataloader:
                inputs, y = inputs.to(DEVICE), y.squeeze().to(DEVICE)
                outputs = model(inputs)
                _, predicted = torch.max(outputs.data, 1)
                total += y.size(0)
                correct += (predicted == y).sum().item()
        acc = correct / total if total > 0 else 0.0
        fitness.append(acc)
    return np.array(fitness)


# --------------------------主流程--------------------------
def cnnega_band_selection(hsi_data, labels, num_classes):
    """CNNeGA波段选择主函数"""
    population = initialize_population(POPULATION_SIZE, BAND_NUM, SELECT_BANDS)
    best_fitness = 0.0
    best_bands = None

    for gen in range(MAX_GENERATIONS):
        fitness = calculate_fitness(population, hsi_data, labels, num_classes)
        # 记录最优个体
        current_best_idx = np.argmax(fitness)
        if fitness[current_best_idx] > best_fitness:
            best_fitness = fitness[current_best_idx]
            best_bands = np.where(population[current_best_idx])[0]
        print(f"Generation {gen+1}, Best Fitness: {best_fitness:.4f}")

        # 选择操作
        fitness = fitness + 1e-6
        prob = fitness / np.sum(fitness)
        selected_indices = np.random.choice(POPULATION_SIZE, size=POPULATION_SIZE, p=prob)
        selected = population[selected_indices]

        # 生成新种群
        new_population = []
        for i in range(0, POPULATION_SIZE, 2):
            parent1 = selected[i]
            parent2 = selected[i+1] if i+1 < POPULATION_SIZE else selected[0]
            parent1, parent2 = parent_check(parent1, parent2, SELECT_BANDS)
            child1, child2 = crossover(parent1, parent2)
            child1 = mutate(child1, gen)
            child2 = mutate(child2, gen)
            new_population.append(child1)
            new_population.append(child2)
        population = np.array(new_population[:POPULATION_SIZE])

    return best_bands + 1

# --------------------------使用示例--------------------------
import time
if __name__ == "__main__":
    import os
    start_time = time.time()
    os.environ['CUDA_VISIBLE_DEVICES'] = '2'  # 设置使用的GPU编号
    # 模拟输入数据：(512, 640, 21)的高光谱数据和标签
    # hsi_data = np.random.rand(512, 640, 21)  # 实际使用时替换为真实数据
    # labels = np.random.randint(0, 5, size=(512, 640))  # 假设5类地物

    hsi_data = np.load(r'../Data_Mat/MSIdata.npy')
    labels = np.load(r'../Data_Mat/MSImask2.npy').astype(np.int64)-1

    num_classes = 6

    # 运行CNNeGA波段选择
    selected_bands = cnnega_band_selection(hsi_data, labels, num_classes)
    print(f"选择的波段序号（1-based）：{selected_bands}")
    print('time ', time.time() - start_time)


    #result=[ 1  2  5 13 18]

