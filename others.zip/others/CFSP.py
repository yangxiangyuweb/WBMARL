'''
An Efficient Subspace Partition Method Using
Curve Fitting for Hyperspectral Band Selection
'''

import numpy as np
from scipy.interpolate import make_interp_spline
from scipy.linalg import det


class CFSP:
    def __init__(self, K=10, n_pixel_ratio=0.01):
        self.K = K  # 待选波段数
        self.n_pixel_ratio = n_pixel_ratio  # 用于曲线拟合的像素比例（1%）
        self.subspaces = []  # 子空间划分结果
        self.selected_bands = []  # 选中的波段

    def _curve_fitting(self, X):
        """步骤1：曲线拟合，返回平均光谱曲线的拟合曲线及其导数"""
        # X形状：(rows, cols, bands) = (512, 640, 21)
        rows, cols, bands = X.shape
        # 随机选择n个像素（1%）
        n_pixels = int(rows * cols * self.n_pixel_ratio)
        rand_rows = np.random.choice(rows, n_pixels)
        rand_cols = np.random.choice(cols, n_pixels)
        # 提取这些像素的光谱曲线并平均
        spectral_curves = X[rand_rows, rand_cols, :]  # 形状：(n_pixels, bands)
        avg_curve = np.mean(spectral_curves, axis=0)  # 平均光谱曲线
        # 样条拟合（提高平滑度）
        band_indices = np.arange(bands)
        spline = make_interp_spline(band_indices, avg_curve, k=3)  # 三次样条
        # 生成拟合曲线
        Y = spline(band_indices)  # 拟合曲线
        # 生成一阶导数（通过样条对象求导，而非直接对数组求导）
        spline_der1 = spline.derivative()  # 一阶导数样条
        Y1 = spline_der1(band_indices)     # 一阶导数值
        # 生成二阶导数
        spline_der2 = spline_der1.derivative()  # 二阶导数样条
        Y2 = spline_der2(band_indices)          # 二阶导数值
        return Y, Y1, Y2

    def _curvature(self, Y1, Y2):
        """计算曲率 Q = |Y2| / (1 + Y1²)^(3/2)"""
        return np.abs(Y2) / (1 + Y1 ** 2) ** 1.5

    def _subspace_partition(self, X):
        """步骤2：子空间划分（等份划分 + 曲率精细划分）"""
        rows, cols, bands = X.shape
        # 1. 曲线拟合与曲率计算
        Y, Y1, Y2 = self._curve_fitting(X)
        Q = self._curvature(Y1, Y2)  # 每个波段的曲率值

        # 2. 等分子空间划分
        base_size = bands // self.K
        boundaries = [i * base_size for i in range(self.K + 1)]
        boundaries[-1] = bands  # 确保覆盖所有波段

        # 3. 基于曲率的精细划分
        for i in range(self.K):
            start = boundaries[i]
            end = boundaries[i + 1]
            if end - start <= 1:
                continue  # 跳过过小的子空间
            # 找到当前区间内曲率最大的波段索引
            max_curv_idx = start + np.argmax(Q[start:end])
            # 更新边界（确保不与相邻子空间重叠，且子空间长度至少为1）
            if i > 0:
                max_curv_idx = max(max_curv_idx, boundaries[i - 1] + 1)
            if i < self.K - 1:
                max_curv_idx = min(max_curv_idx, boundaries[i + 2] - 1)
            # 关键修复：确保子空间长度至少为1（end > start）
            if max_curv_idx <= start:
                max_curv_idx = start + 1  # 强制至少包含一个波段
            boundaries[i + 1] = max_curv_idx

        # 生成最终子空间
        self.subspaces = []
        for i in range(self.K):
            self.subspaces.append((boundaries[i], boundaries[i + 1]))

    def _generate_candidate(self, X):
        """步骤3：生成候选波段集（方差最大波段 + 相邻子空间正交投影最大波段）"""
        rows, cols, bands = X.shape
        X_flat = X.reshape(-1, bands)  # 展平为(rows*cols, bands)
        candidates = []

        # 1. 计算每个子空间的方差最大波段
        max_var_bands = []
        for (start, end) in self.subspaces:
            # 修复：即使子空间长度为0，也添加一个默认索引（避免列表长度不足）
            if end - start <= 0:
                max_var_bands.append(start)  # 强制添加start（可根据需求调整）
                continue
            # 提取子空间内的波段
            subspace_bands = X_flat[:, start:end]
            # 计算每个波段的方差
            variances = np.var(subspace_bands, axis=0)
            # 找到方差最大的波段在全局的索引
            max_var_idx = start + np.argmax(variances)
            max_var_bands.append(max_var_idx)

        # 2. 计算相邻子空间的正交投影最大波段
        for i in range(len(self.subspaces)):
            current_band = max_var_bands[i]
            current_vec = X_flat[:, current_band]
            current_vec = current_vec - np.mean(current_vec)  # 中心化
            h = np.dot(current_vec, current_vec)  # 欧氏范数平方

            # 检查左相邻子空间
            if i > 0:
                left_start, left_end = self.subspaces[i - 1]
                left_bands = range(left_start, left_end)
                max_proj = -1
                best_left = -1
                for b in left_bands:
                    if b in max_var_bands:
                        continue  # 跳过已选的方差最大波段
                    vec = X_flat[:, b] - np.mean(X_flat[:, b])
                    # 计算正交投影
                    proj = vec - current_vec * (np.dot(current_vec, vec) / h) if h != 0 else vec
                    proj_norm = np.dot(proj, proj)
                    if proj_norm > max_proj:
                        max_proj = proj_norm
                        best_left = b
                if best_left != -1:
                    candidates.append(best_left)

            # 检查右相邻子空间
            if i < len(self.subspaces) - 1:
                right_start, right_end = self.subspaces[i + 1]
                right_bands = range(right_start, right_end)
                max_proj = -1
                best_right = -1
                for b in right_bands:
                    if b in max_var_bands:
                        continue
                    vec = X_flat[:, b] - np.mean(X_flat[:, b])
                    proj = vec - current_vec * (np.dot(current_vec, vec) / h) if h != 0 else vec
                    proj_norm = np.dot(proj, proj)
                    if proj_norm > max_proj:
                        max_proj = proj_norm
                        best_right = b
                if best_right != -1:
                    candidates.append(best_right)

        # 合并方差最大波段和候选波段，去重
        candidates = list(set(candidates + max_var_bands))
        return candidates

    def _select_final_bands(self, X, candidates):
        """步骤4：用MEV方法从候选集中选择最终波段"""
        rows, cols, bands = X.shape
        X_flat = X.reshape(-1, bands)
        selected = []
        candidate_set = candidates.copy()

        # 初始化：选择方差最大的波段
        variances = np.var(X_flat[:, candidate_set], axis=0)
        first_idx = np.argmax(variances)
        selected.append(candidate_set[first_idx])
        candidate_set.pop(first_idx)

        # 迭代选择剩余波段
        while len(selected) < self.K and candidate_set:
            max_det = -1
            best_band = -1
            best_idx = -1
            # 计算每个候选波段加入后的行列式值
            for i, b in enumerate(candidate_set):
                current_subset = selected + [b]
                # 提取子集的光谱数据并中心化
                subset_data = X_flat[:, current_subset]
                subset_data = subset_data - np.mean(subset_data, axis=0)
                # 计算协方差矩阵的行列式（MEV准则）
                cov_mat = np.cov(subset_data.T)
                current_det = det(cov_mat)
                if current_det > max_det:
                    max_det = current_det
                    best_band = b
                    best_idx = i
            if best_band == -1:
                break
            selected.append(best_band)
            candidate_set.pop(best_idx)

        self.selected_bands = sorted(selected)
        return self.selected_bands

    def fit(self, X):
        """执行CFSP算法：输入(512,640,21)，输出选中的波段索引"""
        # 步骤1：子空间划分
        self._subspace_partition(X)
        # 步骤2：生成候选波段集
        candidates = self._generate_candidate(X)
        # 步骤3：选择最终波段
        return self._select_final_bands(X, candidates)

import time
# 使用示例
if __name__ == "__main__":
    # 模拟输入数据：(512, 640, 21)
    start_time = time.time()
    X = np.load(r'../Data_Mat/MSIdata.npy')  # 假设数据已加载并转置为(512, 640, 21)

    # 初始化CFSP，选择10个波段
    cfsp = CFSP(K=5)
    selected_bands = cfsp.fit(X)

    print(f"Selected bands: {selected_bands}")
    print('time ', time.time() - start_time)
    #resdult=[1, 3, 9, 11, 17])