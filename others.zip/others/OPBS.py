"""
Implementation of OPBS algorithm

Detail can be found in paper "A Geometry-Based Band Selection
Approach for Hyperspectral Image Analysis" in Algorithm 2
"""


import numpy as np
from MEV_SFS import load_gdal_data
import scipy.io as scio
import os
from PIL import Image
import cv2

def read_hyper1(filepath):
    imglist=[]
    if filepath.find('sky')>=0:
        qianzhui='sky'
    if filepath.find('road')>=0:
        qianzhui='road'
    if filepath.find('forest')>=0:
        qianzhui='forest'
    if filepath.find('building')>=0:
        qianzhui='building'
    for i in range(len(os.listdir(filepath))):
        imgname=qianzhui+str(i)+'.tif'
        imgpath = os.path.join(filepath, imgname)
        print(imgpath)
        hyper = cv2.imread(imgpath, -1)
        imglist.append(hyper)
    imglist=np.array(imglist)
    return imglist

def opbs(image_data, sel_band_count, removed_bands=None):
    if image_data is None:
        return None

    bands = image_data.shape[1]
    band_idx_map = np.arange(bands)

    if not (removed_bands is None):
        image_data = np.delete(image_data, removed_bands, 1)
        bands = bands - len(removed_bands)
        band_idx_map = np.delete(band_idx_map, removed_bands)

    # Compute covariance and variance for each band
    # TODO: data normalization to all band
    data_mean = np.mean(image_data, axis=0)
    image_data = image_data - data_mean
    data_var = np.var(image_data, axis=0)
    h = data_var * image_data.shape[0]
    op_y = image_data.transpose()

    sel_bands = np.array([np.argmax(data_var)])
    last_sel_band = sel_bands[0]
    current_selected_count = 1
    sum_info = h[last_sel_band]
    while current_selected_count < sel_band_count:
        for t in range(bands):
            if not (t in sel_bands):
                op_y[t] = op_y[t] - np.dot(op_y[last_sel_band], op_y[t]) / h[last_sel_band] * op_y[last_sel_band]

        max_h = 0
        new_sel_band = -1
        for t in range(bands):
            if not (t in sel_bands):
                h[t] = np.dot(op_y[t], op_y[t])
                if h[t] > max_h:
                    max_h = h[t]
                    new_sel_band = t
        sel_bands = np.append(sel_bands, new_sel_band)
        last_sel_band = new_sel_band
        sum_info += max_h
        estimate_percent = sum_info / (sum_info + (bands - sel_bands.shape[0]) * max_h)
        #print(estimate_percent)
        current_selected_count += 1

   # print(band_idx_map[sel_bands] + 1)
    print(np.sort(band_idx_map[sel_bands] + 1))

    return sel_bands

import time
def main():
    strat_time = time.time()
    remove_bands = None

    use_mat_data = True

    if use_mat_data:

        file = r'D:\yangxiangyu\PythonWorks\maddpg_bandwidthSelect\MSI\\sky\1'
        image_data = read_hyper1(file)

        cols = image_data.shape[1]
        rows = image_data.shape[2]
        bands = image_data.shape[0]

        image_data = image_data.reshape(cols * rows, bands)
    else:
        image_data = load_gdal_data(r"E:\Download\10_4231_R7RX991C\aviris_hyperspectral_data"
                                    r"\19920612_AVIRIS_IndianPine_Site3.tif")

    opbs(image_data, 6, remove_bands)
    print(time.time() - strat_time)


if __name__ == "__main__":
    main()
