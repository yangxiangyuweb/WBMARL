import numpy as np
import os
import cv2
import time
def read_hyper1(filepath):
    imglist=[]
    if filepath.find('sky')>=0:
        qianzhui='sky'
    if filepath.find('road')>=0:
        qianzhui='road'
    if filepath.find('forest')>=0:
        qianzhui='forest'
    if filepath.find('building')>=0:
        qianzhui='building'
    for i in range(len(os.listdir(filepath))):
        imgname=qianzhui+str(i)+'.tif'
        imgpath = os.path.join(filepath, imgname)
        print(imgpath)
        hyper = cv2.imread(imgpath, -1)
        imglist.append(hyper)
    imglist=np.array(imglist)
    return imglist

def select_band_with_least_noise(band_group, data):
    # 在给定的波段组中选择噪声最小的波段
    min_noise = np.inf
    selected_band = None
    for band in band_group:
        # 计算每个波段的标准偏差作为噪声估计
        noise_estimate = np.std(data[:, :, band])
        if noise_estimate < min_noise:
            min_noise = noise_estimate
            selected_band = band
    return selected_band

def select_representative_bands(data, labels):
    # 在每个子立方体中选择代表波段
    representative_bands = []
    for i in np.unique(labels):
        # 选择该子立方体中噪声最小的波段
        band_group = np.where(labels == i)[0]
        band = select_band_with_least_noise(band_group, data)
        representative_bands.append(band)
    return representative_bands

# 假设数据
filepath = r'I:\DATA\5.29aotf_data\trees\nan3_2ms_qingxi\3'
band_num = 5
strat_time= time.time()
filedir = r'D:\yangxiangyu\PythonWorks\maddpg_bandwidthSelect\MSI\\sky'
for name in os.listdir(filedir):
    filepath = os.path.join(filedir, name)
    Hyper = read_hyper1(filepath)
    labels = np.random.randint(0, band_num, 21)  # 假设将21个波段随机分为5个子立方体

    representative_bands = select_representative_bands(Hyper, labels)
    print("代表波段:", representative_bands)
    print(time.time()-strat_time)