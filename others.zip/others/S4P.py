import numpy as np
from sklearn.decomposition import PCA
from skimage.segmentation import slic
from sklearn.metrics.pairwise import cosine_similarity
import scipy.sparse as sp


def s4p_band_selection(hsi_data, num_bands=5, num_segments=21, alpha=1.0, gamma=0.1, max_iter=10):
    """
    S⁴P (Spatial and Spectral Structure Preserved Self-Representation) 波段选择算法

    参数:
    hsi_data: numpy数组，形状为 [rows, cols, bands]，高光谱图像数据
    num_bands: int，要选择的波段数量
    num_segments: int，超像素分割的数量
    alpha: float，空间结构保留项的权重
    gamma: float，波段稀疏性约束的权重
    max_iter: int，优化迭代次数

    返回:
    selected_bands: list，选择的波段序号
    """
    start_time = time.time()
    print("开始S⁴P波段选择算法...")

    # 1. 数据准备
    step_start = time.time()
    rows, cols, bands = hsi_data.shape
    hsi_2d = hsi_data.reshape(rows * cols, bands)  # [rows*cols, bands]
    print(f"数据准备完成，耗时: {time.time() - step_start:.4f}s")

    # 2. PCA降维获取第一主成分
    step_start = time.time()
    pca = PCA(n_components=1)
    pc1 = pca.fit_transform(hsi_2d).reshape(rows, cols)  # [rows, cols]
    print(f"PCA降维完成，耗时: {time.time() - step_start:.4f}s")

    # 3. 超像素分割获取同质区域
    step_start = time.time()
    # 关键修改：添加channel_axis=None参数
    segments = slic(pc1, n_segments=num_segments, compactness=10, sigma=1, channel_axis=None)  # [rows, cols]
    print(f"超像素分割完成，耗时: {time.time() - step_start:.4f}s")

    # 4. 生成超像素级特征矩阵
    step_start = time.time()
    X = np.zeros((num_segments, bands))  # [num_segments, bands]

    # 处理空超像素区域
    empty_segments = []
    for i in range(num_segments):
        mask = (segments == i)
        pixels_in_segment = hsi_data[mask].reshape(-1, bands)

        if pixels_in_segment.size == 0:
            # 记录空超像素
            empty_segments.append(i)
            # 赋予默认值（所有波段为0）
            X[i] = np.zeros(bands)
        else:
            X[i] = np.mean(pixels_in_segment, axis=0)

    if empty_segments:
        print(f"警告: 发现 {len(empty_segments)} 个空超像素区域，已用0填充")

    print(f"超像素特征矩阵生成完成，耗时: {time.time() - step_start:.4f}s")

    # 5. 计算多图融合的相似度矩阵
    step_start = time.time()

    # 检查是否有NaN值
    if np.isnan(X).any():
        print("警告: 超像素特征矩阵包含NaN值，尝试用均值填充")
        # 计算每列（每个波段）的均值（忽略NaN）
        col_means = np.nanmean(X, axis=0)
        # 用每列的均值填充NaN
        inds = np.where(np.isnan(X))
        X[inds] = np.take(col_means, inds[1])

    # 提取前tau个主成分（tau=5）
    pca_tau = PCA(n_components=5)
    X_pca = pca_tau.fit_transform(X)  # [num_segments, 5]

    # 初始化相似度矩阵和权重
    S = np.zeros((num_segments, num_segments))
    omega = np.ones(5) / 5  # 初始权重均等

    # 计算每个主成分的相似度图
    S_v_list = []
    for v in range(5):
        X_v = X_pca[:, v].reshape(-1, 1)
        S_v = cosine_similarity(X_v)  # 余弦相似度
        S_v_list.append(S_v)
    print(f"多图融合相似度矩阵计算完成，耗时: {time.time() - step_start:.4f}s")

    # 后续代码保持不变...
    # 6. 交替优化求解自表示系数矩阵Z和相似度矩阵S
    step_start = time.time()
    # 初始化Z为单位矩阵
    Z = np.eye(bands)

    for iter in range(max_iter):
        iter_start = time.time()

        # 6.1 更新相似度矩阵S
        S_old = S.copy()
        for i in range(num_segments):
            for j in range(num_segments):
                if i != j:
                    S[i, j] = sum(omega[v] * S_v_list[v][i, j] for v in range(5))
        # 归一化S
        S = (S + S.T) / 2
        S = np.exp(S) / np.sum(np.exp(S), axis=1, keepdims=True)

        # 6.2 更新权重omega
        for v in range(5):
            omega[v] = np.exp(-np.linalg.norm(S - S_v_list[v]))
        omega = omega / np.sum(omega)

        # 6.3 更新自表示系数矩阵Z
        # 构建拉普拉斯矩阵L
        D = np.diag(np.sum(S, axis=1))
        L = D - S

        # 求解Z：min ||X - XZ||^2 + alpha * Tr(Z'X'LXZ) + gamma * ||Z||_{2,1}
        A = X.T @ X + alpha * X.T @ L @ X
        B = X.T

        # 迭代重加权最小二乘法求解稀疏约束的Z
        W = np.ones((bands, bands))  # 权重矩阵，初始为1
        for w_iter in range(5):  # 权重更新迭代次数
            for i in range(bands):
                # 求解子问题：min ||X - XZ||^2 + gamma * w_i * ||Z_i||_2
                A_i = A + gamma * np.diag(W[i])
                Z[i] = np.linalg.solve(A_i, B[i])

            # 更新权重矩阵W
            for i in range(bands):
                for j in range(bands):
                    if i != j:
                        W[i, j] = 1.0 / (2 * np.sqrt(Z[i, j] ** 2 + 1e-10))

        print(f"迭代 {iter + 1}/{max_iter} 完成，耗时: {time.time() - iter_start:.4f}s")

        # 检查收敛性
        if np.linalg.norm(Z - Z) < 1e-6:
            print(f"在迭代 {iter + 1} 时收敛")
            break

    print(f"交替优化完成，耗时: {time.time() - step_start:.4f}s")

    # 7. 计算波段重要性得分
    step_start = time.time()
    band_scores = np.sum(np.abs(Z), axis=1)
    print(f"波段重要性得分计算完成，耗时: {time.time() - step_start:.4f}s")

    # 8. 选择得分最高的波段
    step_start = time.time()
    selected_indices = np.argsort(band_scores)[-num_bands:]
    selected_indices = np.sort(selected_indices)  # 按原始顺序排序
    print(f"波段选择完成，耗时: {time.time() - step_start:.4f}s")

    total_time = time.time() - start_time
    print(f"S⁴P算法执行完成，总耗时: {total_time:.4f}s")

    return selected_indices

import time
# 使用示例
if __name__ == "__main__":
    # 生成示例数据（512x640x21）
    start_time = time.time()
    np.random.seed(42)
    hsi_data = np.random.rand(512, 640, 21)
    hsi_data = np.load(r'../Data_Mat/MSIdata.npy')

    # 应用S⁴P波段选择
    selected_bands = s4p_band_selection(hsi_data, num_bands=5)

    print("选择的波段序号:", selected_bands)
    print('time ', time.time() - start_time)

    #result=[ 8 10 13 19 20]