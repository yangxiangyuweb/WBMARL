'''
An adaptive evolutionary-reinforcement learning algorithm for hyperspectral band selection
'''

import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split


class ERLA:
    def __init__(self, K=5, max_iter=100, pop_size=15, alpha=0.99, beta=0.001):
        self.K = K  # 目标选择波段数
        self.max_iter = max_iter  # 最大迭代次数
        self.pop_size = pop_size  # 种群大小（需为3的倍数）
        self.alpha = alpha  # 精度权重（论文式9）
        self.beta = beta  # 波段数量权重（论文式9）
        self.theta = np.random.uniform(0, 2 * np.pi)  # 旋转率（论文3.1节）
        self.r = np.random.uniform(0.5, 1.0)  # 步长率（论文式7）
        self.selected_bands = []  # 最终选择的波段

    def _flatten_data(self, X):
        """将(rows, cols, bands)转换为(samples, bands)（适配高光谱数据格式）"""
        rows, cols, bands = X.shape
        return X.reshape(rows * cols, bands)

    def _init_population(self, bands):
        """初始化种群：二进制编码（1表示选中），确保初始选中波段≥20%（论文4.3节）"""
        population = np.random.randint(0, 2, size=(self.pop_size, bands))
        for i in range(self.pop_size):
            if np.sum(population[i]) < 0.2 * bands:
                population[i] = np.random.randint(0, 2, size=bands)
        return population

    def _fitness(self, X, y, individual):
        """计算适应度：Fit = α*(1-Acc) + β*(n_s/n_b)（论文式9）"""
        selected = np.where(individual == 1)[0]
        if len(selected) == 0:
            return 1.0  # 无效个体惩罚
        X_selected = X[:, selected]
        # 10%样本训练（论文4.3节最佳比例）
        X_train, X_test, y_train, y_test = train_test_split(
            X_selected, y, test_size=0.3, random_state=42
        )
        # SVM分类（论文4.1节实验设置）
        clf = SVC(kernel='rbf')
        clf.fit(X_train, y_train)
        acc = accuracy_score(y_test, clf.predict(X_test))
        n_s = len(selected)
        n_b = len(individual)
        return self.alpha * (1 - acc) + self.beta * (n_s / n_b)

    def _reward(self, fitness):
        """奖励函数：Rew = 1 - Fit（论文式10）"""
        return 1 - fitness

    def _exploration_update(self, population, best_individual, target_dim):
        """探索阶段更新：基于螺旋优化+差分进化（论文3.1节），强制维度为target_dim"""
        new_pop = []
        for i in range(len(population)):
            # 随机选择4个个体（确保参与计算的个体维度一致）
            idxs = np.random.choice(len(population), 4, replace=False)
            x1, x2, x3, x4 = [pop[:target_dim] for pop in population[idxs]]

            # 螺旋矩阵计算（论文式7）
            spiral = self.r * np.array([
                [np.cos(self.theta), -np.sin(self.theta)],
                [np.sin(self.theta), np.cos(self.theta)]
            ])

            # 计算个体差异（适配低维度场景）
            diff1 = x1[:2] - x2[:2] if target_dim >= 2 else np.array([0.])
            diff2 = x3[:2] - x4[:2] if target_dim >= 2 else np.array([0.])
            update = spiral @ np.array([diff1, diff2])

            # 调整更新量至目标维度
            update = np.pad(update[0], (0, max(0, target_dim - len(update[0]))), mode='constant')[:target_dim]

            # 生成新个体并确保维度一致
            best_adj = best_individual[:target_dim] if len(best_individual) >= target_dim else np.pad(best_individual, (
            0, target_dim - len(best_individual)), mode='constant')
            new_ind = np.clip(best_adj + update, 0, 1).astype(int)
            new_ind = new_ind[:target_dim]  # 强制截断至目标维度
            new_pop.append(new_ind)
        return np.array(new_pop)

    def _exploitation_update(self, population, best_individual, target_dim):
        """利用阶段更新：向最优个体局部优化（论文3.1节），强制维度为target_dim"""
        new_pop = []
        for ind in population:
            # 调整当前个体至目标维度
            ind_adj = ind[:target_dim] if len(ind) >= target_dim else np.pad(ind, (0, target_dim - len(ind)),
                                                                             mode='constant')
            # 调整最优个体至目标维度
            best_adj = best_individual[:target_dim] if len(best_individual) >= target_dim else np.pad(best_individual, (
            0, target_dim - len(best_individual)), mode='constant')

            # 70%概率继承最优特征（论文3.1节利用策略）
            mask = np.random.rand(target_dim) < 0.7
            new_ind = np.where(mask, best_adj, ind_adj)
            new_pop.append(new_ind)
        return np.array(new_pop)

    def _random_walk_update(self, population, target_dim):
        """随机游走阶段更新：基于费马螺旋扰动（论文3.1节），强制维度为target_dim"""
        new_pop = []
        for ind in population:
            # 调整当前个体至目标维度
            ind_adj = ind[:target_dim] if len(ind) >= target_dim else np.pad(ind, (0, target_dim - len(ind)),
                                                                             mode='constant')

            # 费马螺旋的随机扰动（论文式8）
            r = np.random.choice([-1, 1]) * np.sqrt(self.theta)
            p = min(0.3, np.abs(r))  # 扰动概率限制在[0,0.3]
            perturb = np.random.binomial(1, p, size=target_dim)  # 二项分布生成扰动

            new_ind = np.abs(ind_adj - perturb)  # 0/1翻转扰动
            new_pop.append(new_ind)
        return np.array(new_pop)

    def _lessening_length_coding(self, population):
        """减长编码：移除所有个体均未选中的波段（论文3.3节）"""
        keep_bands = np.any(population == 1, axis=0)  # 至少被一个个体选中的波段
        if np.sum(keep_bands) == 0:
            return population, np.arange(population.shape[1])
        new_pop = population[:, keep_bands]
        return new_pop, np.where(keep_bands)[0]

    def fit(self, X, y):
        """训练主流程：输入(rows, cols, bands)数据，输出选中波段序号"""
        X_flat = self._flatten_data(X)
        total_bands = X_flat.shape[1]
        population = self._init_population(total_bands)
        global_best_ind = population[0].copy()
        global_best_reward = -np.inf
        band_mapping = np.arange(total_bands)  # 记录波段映射（应对减长编码）

        for iter in range(self.max_iter):
            current_dim = population.shape[1]  # 当前种群维度（减长后）

            # 划分子种群（探索、利用、随机游走，论文3.1节）
            subpop_size = self.pop_size // 3
            exp_pop = population[:subpop_size]
            expl_pop = population[subpop_size:2 * subpop_size]
            rw_pop = population[2 * subpop_size:]

            # 计算适应度与奖励
            fitness = [self._fitness(X_flat, y, ind) for ind in population]
            rewards = [self._reward(f) for f in fitness]
            best_idx = np.argmax(rewards)
            current_best_ind = population[best_idx].copy()
            current_best_reward = rewards[best_idx]

            # 更新全局最优
            if current_best_reward > global_best_reward:
                global_best_ind = current_best_ind.copy()
                global_best_reward = current_best_reward

            # 三阶段更新（强制维度一致）
            exp_updated = self._exploration_update(exp_pop, global_best_ind, current_dim)
            expl_updated = self._exploitation_update(expl_pop, global_best_ind, current_dim)
            rw_updated = self._random_walk_update(rw_pop, current_dim)

            # 合并子种群（此时维度已统一）
            population = np.vstack([exp_updated, expl_updated, rw_updated])

            # 减长编码（更新种群与波段映射）
            population, keep_mask = self._lessening_length_coding(population)
            band_mapping = band_mapping[keep_mask]
            # 同步调整全局最优个体维度
            global_best_ind = global_best_ind[keep_mask] if len(global_best_ind) > len(keep_mask) else global_best_ind

            # 终止条件：选中波段数≤K或<总波段20%（论文4.3节）
            current_selected = np.sum(global_best_ind)
            if current_selected <= self.K or current_selected < 0.2 * total_bands:
                break

            if iter % 10 == 0:  # 每10代打印一次信息
                print(f"Iter {iter}: Best Reward = {global_best_reward:.4f}, Selected Bands = {current_selected}")

        # 确定最终波段（确保数量为K）
        final_selected = band_mapping[np.where(global_best_ind == 1)[0]]
        if len(final_selected) < self.K:
            # 补充方差最大的波段（论文4.5节优化策略）
            remaining = [b for b in range(total_bands) if b not in final_selected]
            if remaining:
                variances = np.var(X_flat[:, remaining], axis=0)
                top_remaining = np.array(remaining)[np.argsort(variances)[-(self.K - len(final_selected)):]]
                final_selected = np.unique(np.concatenate([final_selected, top_remaining]))
        self.selected_bands = sorted(final_selected[:self.K])  # 确保不超过K个

        return self.selected_bands


import time
# 使用示例
if __name__ == "__main__":
    start_time = time.time()
    # 模拟输入：(512, 640, 21)的高光谱数据和标签
    X = np.random.rand(512, 640, 21)  # 替换为实际数据
    y = np.random.randint(0, 10, size=512 * 640)  # 替换为实际标签

    X = np.load(r'../Data_Mat/MSIdata.npy')[200:300,250:350,:]
    y = np.load(r'../Data_Mat/MSImask2.npy')[200:300,250:350].reshape(-1)

    # 初始化ERLA，目标选择5个波段
    erla = ERLA(K=5, max_iter=50)
    selected = erla.fit(X, y)
    print(f"选择的波段序号：{selected}")
    print('time ', time.time() - start_time)

    # result = [1, 2, 5, 9, 10]