'''
A hyperspectral band selection method based on sparse band attention network for maize seed variety identification
'''


import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np


class SparseBandAttention(nn.Module):
    def __init__(self, num_bands, threshold=0.5):
        super(SparseBandAttention, self).__init__()
        # 波段注意力模块：通过全连接层生成波段权重
        self.attention = nn.Sequential(
            nn.Linear(num_bands, num_bands // 2),
            nn.ReLU(),
            nn.Linear(num_bands // 2, num_bands),
            nn.Sigmoid()  # 将权重映射到0-1范围
        )
        self.threshold = threshold  # 稀疏约束阈值

    def forward(self, x):
        # x形状：(batch_size, num_bands)
        band_weights = self.attention(x)  # 生成波段权重

        # 稀疏约束：低于阈值的权重置为0
        sparse_weights = torch.where(band_weights > self.threshold, band_weights, torch.zeros_like(band_weights))
        # 重新加权光谱
        reweighted_x = x * sparse_weights
        return reweighted_x, band_weights


class ClassificationNet(nn.Module):
    def __init__(self, num_bands, num_classes):
        super(ClassificationNet, self).__init__()
        # 分类网络：3个卷积层+3个最大池化层（适配光谱数据的1D卷积）
        self.conv_layers = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),

            nn.Conv1d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),

            nn.Conv1d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2)
        )

        # 计算全连接层输入维度（需根据波段数调整）
        self.fc = nn.Linear(128 * (num_bands // 8), num_classes)

    def forward(self, x):
        # x形状：(batch_size, num_bands) -> 转换为(batch_size, 1, num_bands)以适配1D卷积
        x = x.unsqueeze(1)
        x = self.conv_layers(x)
        x = x.view(x.size(0), -1)  # 展平
        x = self.fc(x)
        return x


class SparseBandAttentionNetwork(nn.Module):
    def __init__(self, num_bands, num_classes, threshold=0.5):
        super(SparseBandAttentionNetwork, self).__init__()
        self.sparse_attention = SparseBandAttention(num_bands, threshold)
        self.classifier = ClassificationNet(num_bands, num_classes)

    def forward(self, x):
        reweighted_x, band_weights = self.sparse_attention(x)
        output = self.classifier(reweighted_x)
        return output, band_weights


# 总损失函数（含辅助损失）
def total_loss(pred, target, band_weights, lambda_param):
    cross_entropy = nn.CrossEntropyLoss()(pred, target)
    auxiliary_loss = torch.mean(band_weights)  # 辅助损失：鼓励保留有效波段
    return cross_entropy + lambda_param * auxiliary_loss


# 训练过程示例
def train_model(model, train_loader, epochs=500, lr=0.001):
    optimizer = optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999))
    for epoch in range(epochs):
        model.train()
        total_loss_epoch = 0
        # 动态调整lambda（随训练进行衰减）
        lambda_param = 1e-4 * np.exp(-epoch / epochs)

        for spectra, labels in train_loader:
            optimizer.zero_grad()
            pred, band_weights = model(spectra)
            loss = total_loss(pred, labels, band_weights, lambda_param)
            loss.backward()
            optimizer.step()
            total_loss_epoch += loss.item()

        if (epoch + 1) % 50 == 0:
            print(f"Epoch {epoch + 1}, Loss: {total_loss_epoch / len(train_loader)}")


# 提取选中的波段
def select_bands(band_weights, top_k=50):
    # 计算所有样本的平均权重
    avg_weights = torch.mean(band_weights, dim=0)
    # 按权重排序，取前top_k个波段
    _, selected_indices = torch.topk(avg_weights, top_k)
    return selected_indices.numpy()